#ifndef HIPERFNET_STATS_H
#define HIPERFNET_STATS_H

#include <atomic>
#include <cstdint>

namespace hpnet {

struct Stats {
    // Frame-level
    std::atomic<uint64_t> framesSent{0};
    std::atomic<uint64_t> framesRecv{0};
    std::atomic<uint64_t> framesDropped{0};
    std::atomic<uint64_t> crcErrors{0};

    // Protocol-level
    std::atomic<uint64_t> rejects{0};
    std::atomic<uint64_t> timeouts{0};
    std::atomic<uint64_t> retransmissions{0};

    // Performance
    std::atomic<uint64_t> queueOverflows{0};
    std::atomic<uint64_t> poolAllocations{0};
    std::atomic<uint64_t> poolExhaustion{0};

    // Connections
    std::atomic<uint32_t> currentConnections{0};
    std::atomic<uint32_t> maxConnections{0};
    std::atomic<uint64_t> totalConnections{0};

    void Reset();
};

} // namespace hpnet

#endif
