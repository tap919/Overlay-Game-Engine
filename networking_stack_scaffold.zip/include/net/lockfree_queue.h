#ifndef HIPERFNET_LOCKFREE_QUEUE_H
#define HIPERFNET_LOCKFREE_QUEUE_H

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <vector>
#include <memory>
#include <type_traits>

namespace hpnet {

// Single-producer single-consumer ring buffer (SPSC) for hot paths.
template <typename T>
class SpscRing {
public:
    explicit SpscRing(size_t capacity)
        : cap_(RoundUpPow2(capacity)), mask_(cap_ - 1), buf_(static_cast<T*>(::operator new(sizeof(T) * cap_))) {}

    ~SpscRing() {
        // Destroy constructed items
        while (pop(tmp_)) {}
        ::operator delete(buf_);
    }

    bool push(const T& v) noexcept {
        const size_t h = head_.load(std::memory_order_relaxed);
        const size_t n = (h + 1) & mask_;
        if (n == tail_.load(std::memory_order_acquire)) {
            return false; // full
        }
        new (&buf_[h]) T(v);
        head_.store(n, std::memory_order_release);
        return true;
    }

    bool pop(T& out) noexcept {
        const size_t t = tail_.load(std::memory_order_relaxed);
        if (t == head_.load(std::memory_order_acquire)) {
            return false; // empty
        }
        T* ptr = &buf_[t];
        out = *ptr;
        ptr->~T();
        tail_.store((t + 1) & mask_, std::memory_order_release);
        return true;
    }

    size_t size() const noexcept {
        const size_t h = head_.load(std::memory_order_acquire);
        const size_t t = tail_.load(std::memory_order_acquire);
        return (h - t) & mask_;
    }

    size_t capacity() const noexcept { return cap_ - 1; }

private:
    static size_t RoundUpPow2(size_t v) {
        if (v < 2) return 2;
        v--;
        v |= v >> 1; v |= v >> 2; v |= v >> 4; v |= v >> 8; v |= v >> 16; v |= v >> 32;
        return v + 1;
    }

    const size_t cap_;
    const size_t mask_;
    T* buf_;
    alignas(64) std::atomic<size_t> head_{0};
    alignas(64) std::atomic<size_t> tail_{0};
    T tmp_;
};

} // namespace hpnet

#endif
