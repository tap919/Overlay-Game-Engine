#ifndef HIPERFNET_FRAME_H
#define HIPERFNET_FRAME_H

#include <cstdint>
#include <vector>
#include <functional>

namespace hpnet {

constexpr uint8_t PPP_FLAG = 0x7E;
constexpr uint8_t PPP_ESC  = 0x7D;
constexpr uint8_t PPP_XOR  = 0x20;

uint32_t Crc32(const uint8_t* data, size_t len) noexcept;

struct Frame {
    std::vector<uint8_t> payload; // decoded payload
    uint16_t protocol{0};
};

// Incremental assembler for byte streams
class FrameAssembler {
public:
    using FrameHandler = std::function<void(const Frame&)>;
    explicit FrameAssembler(FrameHandler cb);

    void PushBytes(const uint8_t* data, size_t len);

private:
    void EmitIfValid();

private:
    FrameHandler onFrame_;
    std::vector<uint8_t> buf_;
    bool esc_{false};
};

// Encoder with escaping + CRC append
std::vector<uint8_t> EncodeFrame(uint16_t protocol, const uint8_t* data, size_t len);

} // namespace hpnet

#endif
