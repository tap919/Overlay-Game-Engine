#ifndef HIPERFNET_PROTOCOL_H
#define HIPERFNET_PROTOCOL_H

#include <cstdint>
#include <functional>
#include <unordered_map>
#include <vector>
#include <mutex>

namespace hpnet {

using ProtocolHandler = std::function<void(const uint8_t* data, size_t len)>;

class ProtocolRegistry {
public:
    bool Register(uint16_t id, ProtocolHandler handler);
    void Unregister(uint16_t id);
    bool Dispatch(uint16_t id, const uint8_t* data, size_t len);

    std::vector<uint16_t> List() const;

private:
    mutable std::mutex mtx_;
    std::unordered_map<uint16_t, ProtocolHandler> map_;
};

} // namespace hpnet

#endif
