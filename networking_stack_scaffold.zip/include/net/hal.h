#ifndef HIPERFNET_HAL_H
#define HIPERFNET_HAL_H

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace hpnet {

struct LinkState {
    bool up{false};
    uint32_t mtu{1500};
};

using RxCallback = std::function<void(const uint8_t* data, size_t len)>;

class HalIf {
public:
    virtual ~HalIf() = default;
    virtual bool Open(const std::string& iface) = 0;
    virtual void Close() = 0;
    virtual bool Send(const uint8_t* data, size_t len) = 0;
    virtual LinkState GetLinkState() const = 0;
    virtual void SetReceive(RxCallback cb) = 0;
};

// Factory (platform selects correct implementation)
HalIf* CreateHal();

} // namespace hpnet

#endif
