#ifndef HIPERFNET_WORKER_H
#define HIPERFNET_WORKER_H

#include <atomic>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <queue>
#include <thread>
#include <chrono>
#include <vector>

namespace hpnet {

class Worker {
public:
    using Task = std::function<void()>;

    Worker();
    ~Worker();

    void Start();
    void Stop();
    void Post(Task t);
    void PostDelayed(Task t, std::chrono::milliseconds delay);

private:
    void Run();

private:
    std::thread th_;
    std::atomic<bool> running_{false};
    std::mutex mtx_;
    std::condition_variable cv_;
    std::queue<Task> q_;
    // Min-heap of (time, task)
    std::vector<std::pair<std::chrono::steady_clock::time_point, Task>> timers_;
};

} // namespace hpnet

#endif
