#ifndef HIPERFNET_STACK_H
#define HIPERFNET_STACK_H

#include "net/hal.h"
#include "net/frame.h"
#include "net/protocol.h"
#include "net/lockfree_queue.h"
#include "net/mempool.h"
#include "net/stats.h"
#include "net/worker.h"

#include <memory>

namespace hpnet {

struct StackConfig {
    uint32_t mtu{1500};
    size_t   poolBlocks{2048};
    size_t   queueCapacity{1024};
};

class Stack {
public:
    explicit Stack(const StackConfig& cfg);
    ~Stack();

    bool Start(const std::string& iface);
    void Stop();

    // Public API
    bool Send(uint16_t protocol, const uint8_t* data, size_t len);
    ProtocolRegistry& Protocols() { return protocols_; }
    Stats& Metrics() { return stats_; }

private:
    void OnRx(const uint8_t* data, size_t len);

private:
    StackConfig cfg_;
    std::unique_ptr<HalIf> hal_;
    ProtocolRegistry protocols_;
    FixedBlockPool pool_;
    SpscRing<std::vector<uint8_t>> txQueue_;
    Worker worker_;
    Stats stats_;
};

} // namespace hpnet

#endif
