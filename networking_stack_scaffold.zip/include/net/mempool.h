#ifndef HIPERFNET_MEMPOOL_H
#define HIPERFNET_MEMPOOL_H

#include <cstdint>
#include <cstddef>
#include <atomic>
#include <vector>

namespace hpnet {

class FixedBlockPool {
public:
    FixedBlockPool(size_t blockSize, size_t blockCount);
    ~FixedBlockPool();

    // Returns nullptr when exhausted
    uint8_t* Alloc() noexcept;
    void Free(uint8_t* p) noexcept;

    size_t BlockSize() const noexcept { return blockSize_; }
    size_t Capacity() const noexcept { return blockCount_; }
    size_t Remaining() const noexcept { return free_.load(std::memory_order_relaxed); }

private:
    const size_t blockSize_;
    const size_t blockCount_;
    uint8_t* memory_{nullptr};
    std::atomic<size_t> head_{0};
    std::atomic<size_t> free_{0};
    std::vector<size_t> next_; // lock-free stack
};

} // namespace hpnet

#endif
