using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

[Serializable]
public class NetSettings {
    public string ifaceName = "dummy0";
    public int mtu = 1500;
    public int queueCapacity = 1024;
}

public class NetworkingManager : MonoBehaviour {
    [SerializeField] private NetSettings settings = new NetSettings();

    private IntPtr nativeHandle = IntPtr.Zero;
    private readonly List<ushort> registeredProtocols = new List<ushort>(16);

    void Start() {
        // Bindings are placeholders; wire up to your native plugin
        nativeHandle = new IntPtr(1);
        RegisterProtocol(0x9001, OnChat);
    }

    void Update() {
        // process main-thread-safe callbacks here if needed
    }

    void OnApplicationQuit() {
        registeredProtocols.Clear();
        nativeHandle = IntPtr.Zero;
    }

    public void RegisterProtocol(ushort id, Action<byte[]> handler) {
        registeredProtocols.Add(id);
        // Marshal handler to native; omitted here
    }

    private void OnChat(byte[] payload) {
        var txt = System.Text.Encoding.UTF8.GetString(payload);
        Debug.Log("Chat: " + txt);
    }
}
