#include "net/stack.h"
#include <iostream>

using namespace hpnet;

int main() {
    StackConfig cfg;
    Stack s(cfg);
    s.Protocols().Register(0x9001, [](const uint8_t* d, size_t l){
        std::string msg(reinterpret_cast<const char*>(d), l);
        std::cout << "Got: " << msg << "\n";
    });
    s.Start("dummy0");
    const char* hello = "hello";
    s.Send(0x9001, reinterpret_cast<const uint8_t*>(hello), 5);
    s.Stop();
    return 0;
}
