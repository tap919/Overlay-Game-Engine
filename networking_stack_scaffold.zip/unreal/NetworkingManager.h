#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "NetworkingManager.generated.h"

UCLASS(Blueprintable)
class UNET_API UNetworkingManager : public UObject {
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintCallable, Category="Networking")
    bool Initialize(FString InterfaceName, int32 Mtu = 1500, int32 QueueCapacity = 1024) { return true; }

    UFUNCTION(BlueprintCallable, Category="Networking")
    void RegisterProtocol(uint16 Id) {}

    UFUNCTION(BlueprintCallable, Category="Networking")
    void SendFrame(uint16 Id, const TArray<uint8>& Payload) {}
};
