# High-Performance Networking Stack Scaffold (Game Engine Optimized)

This scaffold implements the architecture you specified:
- Worker-threaded, non-blocking IO
- Frame processing pipeline with PPP-like framing and CRC
- Protocol registration/dispatch
- Lock-free queue + fixed-size memory pool tuned to MTU
- Cross-platform HAL boundary
- Comprehensive statistics + production monitoring
- Unity/Unreal integration layers

> Targets C++20 with CMake. Unity and Unreal layers are optional front-ends that call into the C++ core via your preferred binding (C++/CLI, P/Invoke, or custom plugin).
