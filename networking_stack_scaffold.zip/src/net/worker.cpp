#include "net/worker.h"
#include <algorithm>

namespace hpnet {

Worker::Worker() = default;
Worker::~Worker() { Stop(); }

void Worker::Start() {
    if (running_.exchange(true)) return;
    th_ = std::thread([this]{ Run(); });
}

void Worker::Stop() {
    if (!running_.exchange(false)) return;
    cv_.notify_all();
    if (th_.joinable()) th_.join();
}

void Worker::Post(Task t) {
    {
        std::scoped_lock lock(mtx_);
        q_.push(std::move(t));
    }
    cv_.notify_one();
}

void Worker::PostDelayed(Task t, std::chrono::milliseconds delay) {
    {
        std::scoped_lock lock(mtx_);
        timers_.emplace_back(std::chrono::steady_clock::now() + delay, std::move(t));
        std::push_heap(timers_.begin(), timers_.end(),
            [](auto& a, auto& b){ return a.first > b.first; });
    }
    cv_.notify_one();
}

void Worker::Run() {
    std::unique_lock lock(mtx_);
    while (running_.load()) {
        // Determine next wake time
        auto now = std::chrono::steady_clock::now();
        while (!timers_.empty()) {
            std::pop_heap(timers_.begin(), timers_.end(),
                [](auto& a, auto& b){ return a.first > b.first; });
            auto [tp, task] = timers_.back();
            if (tp > now) {
                timers_.push_back({tp, std::move(task)});
                std::push_heap(timers_.begin(), timers_.end(),
                    [](auto& a, auto& b){ return a.first > b.first; });
                break;
            }
            timers_.pop_back();
            lock.unlock();
            task();
            lock.lock();
        }

        if (!q_.empty()) {
            auto t = std::move(q_.front());
            q_.pop();
            lock.unlock();
            t();
            lock.lock();
            continue;
        }

        if (!timers_.empty()) {
            cv_.wait_until(lock, timers_.front().first);
        } else {
            cv_.wait(lock);
        }
    }
}

} // namespace hpnet
