#include "net/mempool.h"
#include <new>
#include <cstring>

namespace hpnet {

FixedBlockPool::FixedBlockPool(size_t blockSize, size_t blockCount)
    : blockSize_(blockSize), blockCount_(blockCount), next_(blockCount) {
    memory_ = static_cast<uint8_t*>(::operator new(blockSize_ * blockCount_));
    for (size_t i = 0; i < blockCount_; ++i) next_[i] = i + 1;
    next_[blockCount_ - 1] = SIZE_MAX;
    head_.store(0);
    free_.store(blockCount_);
}

FixedBlockPool::~FixedBlockPool() {
    ::operator delete(memory_);
}

uint8_t* FixedBlockPool::Alloc() noexcept {
    size_t h = head_.load(std::memory_order_acquire);
    while (h != SIZE_MAX) {
        size_t next = next_[h];
        if (head_.compare_exchange_weak(h, next, std::memory_order_acq_rel)) {
            free_.fetch_sub(1, std::memory_order_relaxed);
            return memory_ + h * blockSize_;
        }
    }
    return nullptr;
}

void FixedBlockPool::Free(uint8_t* p) noexcept {
    size_t idx = (p - memory_) / blockSize_;
    size_t h = head_.load(std::memory_order_acquire);
    do {
        next_[idx] = h;
    } while (!head_.compare_exchange_weak(h, idx, std::memory_order_acq_rel));
    free_.fetch_add(1, std::memory_order_relaxed);
}

} // namespace hpnet
