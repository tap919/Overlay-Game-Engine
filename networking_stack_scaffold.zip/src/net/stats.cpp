#include "net/stats.h"
namespace hpnet {
void Stats::Reset() {
    framesSent.store(0);
    framesRecv.store(0);
    framesDropped.store(0);
    crcErrors.store(0);
    rejects.store(0);
    timeouts.store(0);
    retransmissions.store(0);
    queueOverflows.store(0);
    poolAllocations.store(0);
    poolExhaustion.store(0);
    currentConnections.store(0);
    maxConnections.store(0);
    totalConnections.store(0);
}
} // namespace hpnet
