#include "net/protocol.h"

namespace hpnet {

bool ProtocolRegistry::Register(uint16_t id, ProtocolHandler handler) {
    std::scoped_lock lock(mtx_);
    return map_.emplace(id, std::move(handler)).second;
}

void ProtocolRegistry::Unregister(uint16_t id) {
    std::scoped_lock lock(mtx_);
    map_.erase(id);
}

bool ProtocolRegistry::Dispatch(uint16_t id, const uint8_t* data, size_t len) {
    std::scoped_lock lock(mtx_);
    auto it = map_.find(id);
    if (it == map_.end()) return false;
    it->second(data, len);
    return true;
}

std::vector<uint16_t> ProtocolRegistry::List() const {
    std::scoped_lock lock(mtx_);
    std::vector<uint16_t> ids;
    ids.reserve(map_.size());
    for (auto& kv : map_) ids.push_back(kv.first);
    return ids;
}

} // namespace hpnet
