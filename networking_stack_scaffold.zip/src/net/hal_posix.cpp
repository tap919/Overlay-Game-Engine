#include "net/hal.h"
#include <thread>
#include <atomic>
#include <chrono>

namespace hpnet {

class DummyHal : public HalIf {
public:
    bool Open(const std::string&) override { running_ = true; return true; }
    void Close() override { running_ = false; }
    bool Send(const uint8_t*, size_t) override { return true; }
    LinkState GetLinkState() const override { return {true, 1500}; }
    void SetReceive(RxCallback cb) override { rx_ = std::move(cb); }

private:
    std::atomic<bool> running_{false};
    RxCallback rx_;
};

HalIf* CreateHal() { return new DummyHal(); }

} // namespace hpnet
