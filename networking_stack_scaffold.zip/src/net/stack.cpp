#include "net/stack.h"
#include <cassert>

namespace hpnet {

Stack::Stack(const StackConfig& cfg)
    : cfg_(cfg),
      hal_(CreateHal()),
      pool_(cfg.mtu, cfg.poolBlocks),
      txQueue_(cfg.queueCapacity) {}

Stack::~Stack() { Stop(); }

bool Stack::Start(const std::string& iface) {
    worker_.Start();
    hal_->SetReceive([this](const uint8_t* d, size_t l){ OnRx(d, l); });
    return hal_->Open(iface);
}

void Stack::Stop() {
    hal_->Close();
    worker_.Stop();
}

bool Stack::Send(uint16_t protocol, const uint8_t* data, size_t len) {
    auto encoded = EncodeFrame(protocol, data, len);
    if (!txQueue_.push(encoded)) {
        stats_.queueOverflows.fetch_add(1);
        return false;
    }
    // Signal worker to flush
    worker_.Post([this]{
        std::vector<uint8_t> buf;
        while (txQueue_.pop(buf)) {
            hal_->Send(buf.data(), buf.size());
            stats_.framesSent.fetch_add(1);
        }
    });
    return true;
}

void Stack::OnRx(const uint8_t* data, size_t len) {
    static thread_local FrameAssembler asmblr([this](const Frame& f){
        if (!protocols_.Dispatch(f.protocol, f.payload.data(), f.payload.size())) {
            stats_.rejects.fetch_add(1);
        } else {
            stats_.framesRecv.fetch_add(1);
        }
    });
    asmblr.PushBytes(data, len);
}

} // namespace hpnet
