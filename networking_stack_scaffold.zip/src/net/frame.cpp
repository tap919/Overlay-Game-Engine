#include "net/frame.h"
#include <array>

namespace hpnet {

static constexpr std::array<uint32_t, 256> MakeCrcTable() {
    std::array<uint32_t, 256> t{};
    for (uint32_t i = 0; i < 256; ++i) {
        uint32_t c = i;
        for (int j = 0; j < 8; ++j) {
            c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
        }
        t[i] = c;
    }
    return t;
}
static constexpr auto CRC_TABLE = MakeCrcTable();

uint32_t Crc32(const uint8_t* data, size_t len) noexcept {
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < len; ++i) {
        c = CRC_TABLE[(c ^ data[i]) & 0xFFu] ^ (c >> 8);
    }
    return c ^ 0xFFFFFFFFu;
}

FrameAssembler::FrameAssembler(FrameHandler cb) : onFrame_(std::move(cb)) {
    buf_.reserve(4096);
}

void FrameAssembler::PushBytes(const uint8_t* data, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        uint8_t b = data[i];
        if (b == PPP_FLAG) {
            EmitIfValid();
            buf_.clear();
            esc_ = false;
            continue;
        }
        if (b == PPP_ESC) { esc_ = true; continue; }
        if (esc_) { b ^= PPP_XOR; esc_ = false; }
        buf_.push_back(b);
    }
}

void FrameAssembler::EmitIfValid() {
    if (buf_.size() < 2 + 4) return; // proto(2) + CRC(4)
    const size_t dataLen = buf_.size() - 4;
    const uint32_t crc = (buf_[dataLen]) | (buf_[dataLen+1] << 8) | (buf_[dataLen+2] << 16) | (buf_[dataLen+3] << 24);
    const uint32_t calc = Crc32(buf_.data(), dataLen);
    if (calc != crc) return;
    Frame f;
    f.protocol = static_cast<uint16_t>(buf_[0] | (buf_[1] << 8));
    f.payload.assign(buf_.begin() + 2, buf_.begin() + dataLen);
    if (onFrame_) onFrame_(f);
}

std::vector<uint8_t> EncodeFrame(uint16_t protocol, const uint8_t* data, size_t len) {
    std::vector<uint8_t> out;
    out.reserve(len * 2 + 8);
    out.push_back(PPP_FLAG);
    auto pushEsc = [&](uint8_t b){
        if (b == PPP_FLAG || b == PPP_ESC) {
            out.push_back(PPP_ESC);
            out.push_back(b ^ PPP_XOR);
        } else {
            out.push_back(b);
        }
    };
    uint32_t crc = 0xFFFFFFFFu;
    auto upd = [&](uint8_t b){
        pushEsc(b);
        crc = (crc >> 8) ^ (0xEDB88320u ^ ((crc ^ b) & 1u) ? 0 : 0); // simplified; we will compute final CRC below
    };
    // Write protocol LE
    pushEsc(static_cast<uint8_t>(protocol & 0xFF));
    pushEsc(static_cast<uint8_t>((protocol >> 8) & 0xFF));

    // Accurate CRC:
    std::vector<uint8_t> tmp; tmp.reserve(2 + len);
    tmp.push_back(static_cast<uint8_t>(protocol & 0xFF));
    tmp.push_back(static_cast<uint8_t>((protocol >> 8) & 0xFF));
    for (size_t i = 0; i < len; ++i) tmp.push_back(data[i]);
    uint32_t c = Crc32(tmp.data(), tmp.size());
    for (size_t i = 0; i < len; ++i) pushEsc(data[i]);
    // Append CRC LE
    pushEsc(static_cast<uint8_t>(c & 0xFF));
    pushEsc(static_cast<uint8_t>((c >> 8) & 0xFF));
    pushEsc(static_cast<uint8_t>((c >> 16) & 0xFF));
    pushEsc(static_cast<uint8_t>((c >> 24) & 0xFF));
    out.push_back(PPP_FLAG);
    return out;
}

} // namespace hpnet
