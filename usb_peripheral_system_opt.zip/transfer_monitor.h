#ifndef TRANSFER_MONITOR_H
#define TRANSFER_MONITOR_H

#include <chrono>
#include <atomic>
#include <cstdint>

struct UsbTransferStats {
    std::atomic<uint64_t> bulkTransfersSent{0};
    std::atomic<uint64_t> bulkTransfersReceived{0};
    std::atomic<uint64_t> interruptTransfers{0};
    std::atomic<uint64_t> transferErrors{0};
    std::atomic<uint64_t> bytesTransferred{0};

    std::atomic<uint32_t> currentQueueDepth{0};
    std::atomic<uint32_t> maxQueueDepth{0};

    // Times in microseconds (EMA to avoid heavy locking)
    std::atomic<uint64_t> averageTransferTimeUs{0};
    std::atomic<uint64_t> maxTransferTimeUs{0};
};

class TransferMonitor {
public:
    void RecordTransferStart() noexcept;
    void RecordTransferCompletion(bool success, size_t bytes,
                                  std::chrono::steady_clock::time_point startTime) noexcept;
    [[nodiscard]] UsbTransferStats GetStatsSnapshot() const noexcept;

    // Utility for queue depth tracking
    void OnQueueSizeChanged(uint32_t size) noexcept;

private:
    static uint64_t Ema(uint64_t current, uint64_t sample, float alpha = 0.2f) noexcept;

private:
    UsbTransferStats stats_;
};

#endif // TRANSFER_MONITOR_H
