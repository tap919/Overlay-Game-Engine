#ifndef ASYNC_TRANSFER_ENGINE_H
#define ASYNC_TRANSFER_ENGINE_H

#include <cstdint>
#include <vector>
#include <functional>
#include <chrono>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <unordered_map>
#include <string>
#include <array>

// A small fixed-capacity ring for pending transfers to minimize allocations.
template <typename T, size_t Capacity>
class FixedRing {
public:
    bool push(const T& v) noexcept {
        const auto h = head_.load(std::memory_order_relaxed);
        const auto n = (h + 1) % Capacity;
        if (n == tail_.load(std::memory_order_acquire)) return false;
        buf_[h] = v;
        head_.store(n, std::memory_order_release);
        return true;
    }
    bool pop(T& out) noexcept {
        const auto t = tail_.load(std::memory_order_relaxed);
        if (t == head_.load(std::memory_order_acquire)) return false;
        out = buf_[t];
        tail_.store((t + 1) % Capacity, std::memory_order_release);
        return true;
    }
    size_t size() const noexcept {
        const auto h = head_.load(std::memory_order_acquire);
        const auto t = tail_.load(std::memory_order_acquire);
        return (h + Capacity - t) % Capacity;
    }
private:
    std::array<T, Capacity> buf_{};
    std::atomic<size_t> head_{0};
    std::atomic<size_t> tail_{0};
};

struct TransferContext {
    std::vector<uint8_t> buffer; // caller-owned copy; use object pools in .cpp if needed
    std::function<void(bool, size_t)> completionCallback;
    std::chrono::steady_clock::time_point startTime{};
    bool isWrite{true};
};

struct alignas(64) EndpointInfo {
    void* endpointHandle{nullptr};
    uint16_t maxPacketSize{0};
    FixedRing<TransferContext, 256> pending; // tune capacity per title
    std::atomic<bool> active{false};
};

class AsyncTransferEngine {
public:
    AsyncTransferEngine() = default;
    ~AsyncTransferEngine() { Stop(); }

    void Start();
    void Stop();

    // Copy data into an internal buffer and enqueue. Returns false if queue is full.
    bool SubmitBulkWrite(void* endpoint, const uint8_t* data, size_t length,
                         std::function<void(bool, size_t)> callback) noexcept;

    // Enqueue a read request of `length` bytes.
    bool SubmitBulkRead(void* endpoint, size_t length,
                        std::function<void(bool, size_t, const uint8_t* /*data*/)> callback) noexcept;

private:
    void TransferWorker();
    bool ExecuteUsbWrite(void* endpoint, const std::vector<uint8_t>& buffer) noexcept;
    bool ExecuteUsbRead(void* endpoint, std::vector<uint8_t>& outBuffer, size_t length) noexcept;
    EndpointInfo& GetOrCreate(void* endpoint, uint16_t maxPacketSizeHint = 512);

private:
    std::unordered_map<void*, EndpointInfo> endpoints_;
    std::thread workerThread_;
    std::atomic<bool> running_{false};
    std::condition_variable cv_;
    std::mutex mtx_;
};

#endif // ASYNC_TRANSFER_ENGINE_H
