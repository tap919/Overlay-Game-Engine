#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "UnrealPeripheralManager.generated.h"

UENUM(BlueprintType)
enum class EControllerLightPattern : uint8 {
    Off UMETA(DisplayName = "Off"),
    Player1 UMETA(DisplayName = "Player 1"),
    Player2 UMETA(DisplayName = "Player 2"),
    Player3 UMETA(DisplayName = "Player 3"),
    Player4 UMETA(DisplayName = "Player 4"),
    Rainbow UMETA(DisplayName = "Rainbow"),
    Breathing UMETA(DisplayName = "Breathing")
};

USTRUCT(BlueprintType)
struct FPeripheralSettings {
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 VendorId = 0x045E;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 ProductId = 0x028E;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool EnableVibration = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MaxControllers = 4;
};

UCLASS(Blueprintable)
class PERIPHERAL_API UUnrealPeripheralManager : public UObject {
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Peripheral")
    bool InitializePeripheralSystem(FPeripheralSettings Settings);

    UFUNCTION(BlueprintCallable, Category = "Peripheral")
    void SetControllerLight(const FString& DeviceId, EControllerLightPattern Pattern);

    UFUNCTION(BlueprintCallable, Category = "Peripheral")
    void SetControllerVibration(const FString& DeviceId, float LeftMotor, float RightMotor);

    UFUNCTION(BlueprintCallable, Category = "Peripheral")
    TArray<FString> GetConnectedControllers() const;

private:
    UPROPERTY()
    TMap<FString, class UGameController*> Controllers;
};
