#ifndef CROSS_PLATFORM_INPUT_H
#define CROSS_PLATFORM_INPUT_H

#include <vector>
#include <string>
#include <cstdint>

struct ControllerState {
    float leftStickX{0.f};
    float leftStickY{0.f};
    float rightStickX{0.f};
    float rightStickY{0.f};
    float leftTrigger{0.f};
    float rightTrigger{0.f};

    bool buttonA{false};
    bool buttonB{false};
    bool buttonX{false};
    bool buttonY{false};
    bool leftShoulder{false};
    bool rightShoulder{false};
    bool start{false};
    bool back{false};
    bool leftStick{false};
    bool rightStick{false};

    bool dpadUp{false};
    bool dpadDown{false};
    bool dpadLeft{false};
    bool dpadRight{false};
};

class CrossPlatformInput {
public:
    virtual ~CrossPlatformInput() = default;
    virtual bool Initialize() = 0;
    virtual std::vector<std::string> GetConnectedControllers() = 0;
    virtual ControllerState GetControllerState(const std::string& deviceId) = 0;
    virtual bool SetControllerVibration(const std::string& deviceId, float leftMotor, float rightMotor) = 0;
    virtual bool SetControllerLight(const std::string& deviceId, uint32_t color) = 0;
};

#endif // CROSS_PLATFORM_INPUT_H
