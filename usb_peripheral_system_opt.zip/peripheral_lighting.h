#ifndef PERIPHERAL_LIGHTING_H
#define PERIPHERAL_LIGHTING_H

#include <unordered_map>
#include <vector>
#include <string>
#include <cstdint>
#include <cmath>

enum class LightingEffect : uint8_t {
    Static,
    Breathing,
    Rainbow,
    Wave,
    Spectrum
};

struct LightingZone {
    uint32_t ledCount{0};
    std::vector<uint32_t> colors; // pre-sized once and reused
    LightingEffect effect{LightingEffect::Static};
    float speed{1.0f};
};

class PeripheralLighting {
public:
    void SetLightingEffect(const std::string& deviceId, const std::vector<LightingZone>& zones);
    void SetBreathingEffect(const std::string& deviceId, uint32_t color, float speed = 1.0f);
    void SetRainbowEffect(const std::string& deviceId, float speed = 1.0f);
    void SetStaticColor(const std::string& deviceId, uint32_t color);

private:
    static std::vector<uint32_t> GenerateRainbowColors(int count);
    static uint32_t HsvToRgb(float h, float s, float v);
    void ApplyLightingToDevice(const std::string& deviceId, const std::vector<LightingZone>& zones);

private:
    std::unordered_map<std::string, std::vector<LightingZone>> deviceLighting_;
};

inline uint32_t PeripheralLighting::HsvToRgb(float h, float s, float v) {
    // Branchless-ish HSV to RGB for speed; h in [0,1)
    float i = std::floor(h * 6.0f);
    float f = h * 6.0f - i;
    float p = v * (1.0f - s);
    float q = v * (1.0f - f * s);
    float t = v * (1.0f - (1.0f - f) * s);
    int ii = static_cast<int>(i) % 6;
    float r = (ii == 0 || ii == 5) ? v : (ii == 1 ? q : (ii == 2 ? p : (ii == 3 ? p : (ii == 4 ? t : q))));
    float g = (ii == 0) ? t : (ii == 1 ? v : (ii == 2 ? v : (ii == 3 ? q : (ii == 4 ? p : p))));
    float b = (ii == 0) ? p : (ii == 1 ? p : (ii == 2 ? t : (ii == 3 ? v : (ii == 4 ? v : q))));
    auto to8 = [](float c){ return static_cast<uint32_t>(c * 255.0f + 0.5f); };
    return (to8(r) << 16) | (to8(g) << 8) | to8(b);
}

inline std::vector<uint32_t> PeripheralLighting::GenerateRainbowColors(int count) {
    std::vector<uint32_t> out;
    out.resize(static_cast<size_t>(count));
    for (int i = 0; i < count; ++i) {
        float h = (static_cast<float>(i) / static_cast<float>(count));
        out[static_cast<size_t>(i)] = HsvToRgb(h, 1.0f, 1.0f);
    }
    return out;
}

#endif // PERIPHERAL_LIGHTING_H
