#ifndef USB_PERIPHERAL_MANAGER_H
#define USB_PERIPHERAL_MANAGER_H

#include <cstdint>
#include <string>
#include <functional>
#include <atomic>
#include <mutex>
#include <unordered_map>
#include <vector>

// Note: Implementation should live in a .cpp to keep compile units lean.

struct UsbDeviceInfo {
    void* deviceHandle{nullptr};
    uint8_t interfaceNumber{0};
    uint8_t bulkInEndpoint{0};
    uint8_t bulkOutEndpoint{0};
    uint8_t interruptEndpoint{0};
    uint16_t maxPacketSize{0};
    std::atomic<bool> connected{false};
    std::string deviceId; // stable string id for maps/logging
};

struct UsbClassDescription {
    uint16_t vendorId{0};
    uint16_t productId{0};
    // Use a lightweight callback in hot path; std::function is fine in interface but avoid capturing heavy state.
    std::function<void(void*)> addDevice;
    std::function<void(void*)> removeDevice;
};

class GamePeripheralManager {
public:
    GamePeripheralManager() noexcept = default;
    ~GamePeripheralManager() = default;
    GamePeripheralManager(const GamePeripheralManager&) = delete;
    GamePeripheralManager& operator=(const GamePeripheralManager&) = delete;

    // Register a vendor/product pair with a connection callback.
    // Returns true if newly registered, false if already present.
    bool RegisterPeripheralClass(uint16_t vendorId, uint16_t productId,
                                 std::function<void(UsbDeviceInfo)> connectCallback) noexcept;

    // Thread-safe snapshot of connected device ids (lightweight for polling UIs).
    std::vector<std::string> ListConnectedDeviceIds() const;

private:
    // Called by the platform-specific USB observer (not provided here)
    void OnDeviceConnected(void* device, std::function<void(UsbDeviceInfo)> callback);
    void OnDeviceRemoved(void* device);

    [[nodiscard]] UsbDeviceInfo ConfigureDevice(void* device) const;
    [[nodiscard]] std::string GetDeviceId(void* device) const;
    bool RegisterUsbClass(const UsbClassDescription& desc) noexcept;

private:
    // Map deviceId -> info (deviceId is a short, stable hash string from HW path)
    std::unordered_map<std::string, UsbDeviceInfo> connectedDevices_;
    // Map "vid:pid" -> class descriptions (small map)
    std::unordered_map<uint32_t, UsbClassDescription> classes_;
    mutable std::mutex deviceMutex_;
};

#endif // USB_PERIPHERAL_MANAGER_H
