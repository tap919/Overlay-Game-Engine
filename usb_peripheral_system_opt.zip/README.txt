Optimized USB Peripheral System (for high-end game engines)

Highlights:
- Reduced per-frame allocations via fixed-capacity rings and scratch buffers.
- Thread contention minimized: single worker, cache-aligned endpoints, atomics.
- Clear separation of headers vs implementations; put heavy logic in .cpp.
- Unity/Unreal stubs avoid GC spikes: scratch lists, paced polling.

Next steps:
- Implement platform-specific USB IO (WinUSB/libusb/HID) in .cpp files.
- Pool TransferContext buffers for zero-alloc hot paths.
- Instrument with your engine profiler; wire TransferMonitor into job system.
