using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PeripheralSettings
{
    [Header("USB Device Settings")]
    public int vendorId = 0x045E; // Microsoft
    public int productId = 0x028E; // Xbox Controller
    public int maxPacketSize = 64;
    public float pollInterval = 0.016f; // 60Hz

    [Header("Game Integration")]
    public bool enableVibration = true;
    public bool enableCustomLights = true;
    public int maxControllers = 4;
}

public class UnityPeripheralManager : MonoBehaviour
{
    [SerializeField] private PeripheralSettings settings = new PeripheralSettings();

    private GamePeripheralManager peripheralManager;
    private AsyncTransferEngine transferEngine;
    private readonly Dictionary<string, GameController> controllers = new Dictionary<string, GameController>(8);
    private readonly List<string> controllerIdsScratch = new List<string>(8);
    private float pollTimer;

    void Start() {
        peripheralManager = new GamePeripheralManager();
        transferEngine = new AsyncTransferEngine();

        peripheralManager.RegisterPeripheralClass(0x045E, 0x028E, OnControllerConnected);
        peripheralManager.RegisterPeripheralClass(0x1532, 0x0037, OnRazerPeripheralConnected);
        peripheralManager.RegisterPeripheralClass(0x046D, 0xC216, OnLogitechPeripheralConnected);

        transferEngine.Start();
    }

    void Update() {
        pollTimer += Time.unscaledDeltaTime;
        if (pollTimer >= settings.pollInterval) {
            pollTimer = 0f;
            controllerIdsScratch.Clear();
            controllerIdsScratch.AddRange(GetConnectedControllers());
            for (int i = 0; i < controllerIdsScratch.Count; ++i) {
                var id = controllerIdsScratch[i];
                if (controllers.TryGetValue(id, out var c)) {
                    c.ProcessInput(); // should avoid allocations inside
                }
            }
        }
    }

    void OnApplicationQuit() {
        transferEngine?.Stop();
    }

    private void OnControllerConnected(UsbDeviceInfo deviceInfo) {
        var controller = new XboxController(deviceInfo, transferEngine);
        controllers[deviceInfo.deviceId] = controller;
        controller.SetVibration(0, 0);
        controller.SetLedPattern(LedPattern.Player1);
    }

    public void SetControllerVibration(string deviceId, float leftMotor, float rightMotor) {
        if (controllers.TryGetValue(deviceId, out var controller)) {
            controller.SetVibration(leftMotor, rightMotor);
        }
    }

    public List<string> GetConnectedControllers() {
        // Depending on your binding, call into native to list connected ids
        return new List<string>(controllers.Keys);
    }

    // Placeholder stubs for sample
    private void OnRazerPeripheralConnected(UsbDeviceInfo _) {}
    private void OnLogitechPeripheralConnected(UsbDeviceInfo _) {}
}
